<div class="alert alert-danger text-center">
    <strong><?php echo _("Some of the recently updated modules needs apache service to restart to work properly, so please restart the apache service."); ?></strong>
    <button id="restartHttpd" class="btn btn-primary"><?php echo _("Restart") ?></button>
</div>