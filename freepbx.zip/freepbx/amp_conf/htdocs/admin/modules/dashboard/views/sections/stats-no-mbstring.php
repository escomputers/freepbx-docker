<div class='row'>
  <div class='col-sm-10 col-sm-offset-1'>
    <div class="alert alert-warning">
      <center><h3>PHP-MBSTRING isn't installed.</h3></center>
      <p>PHP-MBSTRING is a requirement of PHP SysInfo. System Statistics are disabled until that package is installed.</p>
      <p>This can be resolved by installing the 'php-mbstring' package on most distributions, and then restarting Apache</p> 
    </div>
  </div>
</div>
