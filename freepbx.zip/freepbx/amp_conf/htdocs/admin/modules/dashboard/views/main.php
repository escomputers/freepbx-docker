<div id="welcomepage">
	<div class="jumbotron">
		<h1><?php echo sprintf(_('Welcome to %s'),$brand)?></h1>
		<div class="progress progress-striped active">
			<div class="progress-bar" role="progressbar" style="width: 0%">
				<span><?php echo _('Frobulating')?></span>
		    </div>
		</div>
	</div>
</div>
<div id="statuspage">
	<div id="mainpages"></div>
</div>
<br>
