<div id="log_view" class="log_area">
    <div class="ico_loading">
        <i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
    </div>
    <div class="lines_log">

    </div>
    <div class="line_foot"></div>
</div>