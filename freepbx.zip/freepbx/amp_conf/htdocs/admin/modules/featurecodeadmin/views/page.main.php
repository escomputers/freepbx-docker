<div class="container-fluid">
	<div class = "display full-border">
        <div class="row">
            <div class="col-sm-12">
                <?php echo \FreePBX::Featurecodeadmin()->showPage("view.main.toolbar"); ?>
            </div>
        </div>
		<div class="row">
			<div class='col-md-12'>
				<div class='fpbx-container'>
                    <?php echo \FreePBX::Featurecodeadmin()->showPage("view.main.list"); ?>
				</div>
			</div>
		</div>
	</div>
</div>