<div class="display no-border">
    <div class="container-fluid">
        <div class="well toolbar">
            <span class="toolbar-title">
                <h1><?php echo _("Feature Code Admin"); ?></h1>
            </span>
            <span class="toolbar-btn">
                <div class="btn-group">
                    <button type="button" class="btn btn-default btn-collapse-all" title="<?php echo _("Collapse All"); ?>"><i class="fa fa-chevron-up"></i></button>
                    <button type="button" class="btn btn-default btn-expand-all" title="<?php echo _("Expand All"); ?>"><i class="fa fa-chevron-down"></i></button>
                </div>
            </span>
        </div>
    </div>
</div>